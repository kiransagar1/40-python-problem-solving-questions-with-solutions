# Python Program to Get all the Items
my_list = [1, 2, 3, 4, 5, 6]
# print(my_list)
# print(my_list[:])
# print(my_list[::])

# for i in my_list:
#     print(i,end=" ")
