# Python program to reverse a number

num=12345
c=str(num)[::-1]
print(c)

#[start:stop:skip]