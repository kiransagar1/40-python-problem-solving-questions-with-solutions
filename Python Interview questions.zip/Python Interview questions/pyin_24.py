#Python: Get the current time
'''
explore datetime 
date time sec milisecods minutes
module->colection of functions
time
date
mili
day
year
'''
import datetime
print(datetime.datetime.now().time())