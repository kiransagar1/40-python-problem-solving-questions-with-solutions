# Python Program to Check if a Key is Already Present in a Dictionary
# Example 1: Using in keyword

my_dict={1:'a',2:'b',3:'c'}
if 20 in my_dict:
    print("present")
else:
    print("not there")
