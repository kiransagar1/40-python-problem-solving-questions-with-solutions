# Python Program to Get a Substring of a String
#  Using String slicing
st="this is python interview question"
print(st[7:14]) # start stop step