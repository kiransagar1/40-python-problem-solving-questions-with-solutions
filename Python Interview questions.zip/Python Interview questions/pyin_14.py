# Access both key and value using items() from dict
details={"name":"kiran","roll":21}
for i,j in details.items():
    print(i,j)
        