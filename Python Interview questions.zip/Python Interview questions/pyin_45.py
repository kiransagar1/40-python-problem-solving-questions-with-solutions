# Python Program to Trim Whitespace From a String
# Using strip()

my_string = " Python4DataScience "

print(my_string.strip())

'''
>>Output/Runtime Test Cases:
     
Python4DataScience
'''