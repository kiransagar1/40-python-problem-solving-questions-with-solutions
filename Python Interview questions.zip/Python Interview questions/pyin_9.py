#  Multiplication table (from 1 to 10) in Python
num=int(input("Enter the Number:")) # 3
for i in range(1,11):
    print(num,"x",i,"=",num*i) 