# Python Program to Get the Last Element of the List
#  Using negative indexing
'''
1,2,3,4,5
lhs---->rhs positive indexing
rhs----->lhs negative indexing
'''
l=[1,2,3,4,5,6,7,78]
print(l[-1])