# Program to print half pyramid using *
rows=10
for i in range(rows):
    for j in range(i+1):
        print("*",end=" ")
    print()