# Python: Create a list of empty dictionaries
# [{},{},{},{}]

print([{} for _ in range(10)])
