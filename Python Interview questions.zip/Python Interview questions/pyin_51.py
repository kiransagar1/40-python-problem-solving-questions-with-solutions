# Python Program to Count the Number of Occurrence of a Character in String
# Using a for loop

count = 0

my_string = "Python4DataScience"
my_char = "a"

for i in my_string:
    if i == my_char:
        count += 1

print(count)

'''
>>Output/Runtime Test Cases:
     
2
'''