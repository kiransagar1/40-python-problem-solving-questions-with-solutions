# Python Program to Differentiate Between del, remove, and pop on a List

my_list = [1, 2, 3, 4]

del my_list[1]

print(my_list)

'''
>>Output/Runtime Test Cases:
     
[1, 3, 4]
'''