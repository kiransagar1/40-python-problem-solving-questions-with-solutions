# Write a NumPy program to generate random integers between 1 and 300.

import numpy as np
x=np.random.randint(low=1,high=300,size=6)
print(x)