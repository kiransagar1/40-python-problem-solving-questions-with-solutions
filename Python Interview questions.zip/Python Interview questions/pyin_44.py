# Python Program to Create a Long Multiline String
# Example 1: Using triple quotes

my_string = '''The only way to
learn to programing is
by writing codes.'''

print(my_string)

'''
>>Output/Runtime Test Cases:
     
The only way to
learn to programing is
by writing codes.
'''