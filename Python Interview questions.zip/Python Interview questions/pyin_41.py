# Python Program to Count the Occurrence of an Item in a List
# Example 1: Using count() method

freq = ['a', 1, 'a', 9, 6, 3, 'a'].count('a')
print(freq)

'''
>>Output/Runtime Test Cases:
     
3
'''