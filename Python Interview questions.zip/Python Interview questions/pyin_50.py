# Python Program to Capitalize the First Character of a String
# Using list slicing

my_string = "python is Fun"

print(my_string[0].upper() + my_string[1:])

'''
>>Output/Runtime Test Cases:
     
Python is Fun
'''