#Python: Extend a list without append
l1=[1,2,3]
l2=[3,4,5]
l1[:0]=l2 
print(l1)