# Python Program to Delete an Element From a Dictionary
# Using del keyword

my_dict = {33: 'a', 77: 'b', 99: 'c'}

del my_dict[33]

print(my_dict)

'''
>>Output/Runtime Test Cases:
     
{77: 'b', 99: 'c'}
'''