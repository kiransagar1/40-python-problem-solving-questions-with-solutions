# Python Program to Find ASCII Value of Character
# Example 1: find the ASCII value of the given character

c = 'm'
print("The ASCII value of '" + c + "' is", ord(c))
        
'''
>>Output/Runtime Test Cases:
     
The ASCII value of 'n' is 110
'''