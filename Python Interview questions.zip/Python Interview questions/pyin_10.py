# # Python program to check if a string is palindrome or not
# # input:MoM,radar
# # ouput:MoM,radar
# def ispalindrome(s): # function defination and parameter
#     return s==s[::-1]
# s="sun" # string
# ans=ispalindrome(s) # function call
# if ans:
#     print("this is palindrome")
# else:
#     print("Not a palindrome")

n = 28+125
print(n)