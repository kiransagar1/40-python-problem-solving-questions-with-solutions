# Python Program to Check if a Number is Positive, Negative or 0
# +,-,0
num=float(input("Enter the Number:"))
if num>0:
    print("Positive Number")
elif num==0:
    print("Zero")
else:
    print("Negative")