# find the largest number among the three input numbers

# l=[44,55,53]
# print(max(l))

# num1=float(input("Enter the Number:")) # 1
# num2=float(input("Enter the Number:")) # 2
# num3=float(input("Enter the Number:")) # 3

# if (num1>=num2) and (num1>=num3): # (1>=2) and 1>=3
#     largest=num1
# elif (num2>=num1) and (num2>=num3):# 2>=1 and 2>=3
#     largest=num2
# else:
#     largest=num3
# print("largest Number is :",largest)